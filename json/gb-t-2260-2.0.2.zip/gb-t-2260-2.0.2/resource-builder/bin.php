<?php

declare(strict_types=1);

namespace Medz\GBT2260\ResourceBuilder;

include_once(__DIR__.'/../vendor/autoload.php');

$builder = new Builder();
$builder->run();
